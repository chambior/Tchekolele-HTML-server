/*parse.c
Loic chevallier
23/03/21
*/

#include <stdlib.h>
#include <stdio.h>
#include "struct_arbre.h"
/*
int ALPHA(char* car, Branch* tree)
{
  if((car>='a' && car<='z') || (car>='A' && car <='Z')){
    *tree = new_branch(car, 1, "Alpha");
    return 1;
  }
}


int pct_encoded(char *str, Branch* tree)
{
  BranchList* subtrees = new_branchlist();
  subtrees->next = new_branchlist();

  if(str[0]=='%' && HEXDIG(str[1], subtrees->branch) && HEXDIG(str[2], subtrees->next->branch)){
    *tree = new_branch()
    return 1;
  }
}
*/
// EVERYTHING IS WIP
