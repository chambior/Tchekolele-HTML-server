int ALPHA(char car);
int HEXDIG(char car);
int sub_delims(char car);
int pct_encoded(char *str);
int unreserved(char car);
int pchar(str);
int segment(char *str,char fin);
